// where the express routes are stored
// const { Router } = require('express');
// const controller = require("../controller");
//
//
// const router = Router();
//
// router.get("/", controller.getBorrowedItems);
// router.post("/", controller.addBorrowedItem);
// router.delete("/:asset_id", controller.removeBorrowedItem);
// module.exports = router;
